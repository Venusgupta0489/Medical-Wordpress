<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'medicilone' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'pg,A~]!<S yI[HDbI2Dl]Bm`<Ou+7 Jg{NIA6^$)`1B_fUd-(di;ilyRHoSJyLIJ' );
define( 'SECURE_AUTH_KEY',  'fR^p>%-5q.%CaXo]v[0  ^+&X<AtMpXvG(}] CbyXz4Xq$u-kAC7M6~mCdGF2l&g' );
define( 'LOGGED_IN_KEY',    'B7_8C@uNKBT{6rk(I.ZN|naS&h{yIj=u?Dww.<2Hn<nJlBCocD0?[$8a^1UvWi&o' );
define( 'NONCE_KEY',        'JA9*$%4emmA4< m(-bv -a/MJ^uxv0ErQge)U||B`xLv{@dpneeX)~;!/>Y0Sv`=' );
define( 'AUTH_SALT',        'tPLPLs$X:>B$NTYUHWuh;i/V7C<8!}&EFD}[!HePTVcSBq3WnVY).jPZ>oXvv@8U' );
define( 'SECURE_AUTH_SALT', 'Vj9G2POzO#_JvJubh@xa]u:p]DVw+;$GFAh$GOP@3lE/ 8M6fePI,<p-sl6TxKy,' );
define( 'LOGGED_IN_SALT',   'bG#qBl.7iH.caaZlpG2Ltw]RJ})lOc`FYY?Lrxs8[1.BI?9<-nE}8//H` :r58(e' );
define( 'NONCE_SALT',       'izKXl=#pA(/Ah[,$]Y,a_a[~YXW%lfk!(Y2X561J{uHu6 Q?ai.d_u<FzyIp=S6N' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
